package exercise1;

public interface IObserver {

    void notify(Alert a);
}
