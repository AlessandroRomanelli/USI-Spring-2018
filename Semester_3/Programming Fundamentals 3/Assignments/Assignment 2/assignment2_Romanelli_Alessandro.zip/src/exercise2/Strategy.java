package exercise2;

public interface Strategy {
    void issue(Advertisement adv);
}
