package Assignment4.ex3;

public class Monitors {
	
	public static synchronized void a() {
		// monitor A
	}
	static class InnerClass {
		static synchronized void b() {
			// monitor B
		}
	}
	public void c() {
		synchronized (this.getClass()) {
			// monitor C
		}
	}
	public synchronized void d() {
		// monitor D
	}
	public void e(Object o) {
		synchronized (o) {
			// monitor E
		}		
	}
}
