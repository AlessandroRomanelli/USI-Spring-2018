package Assignment4.ex2;

public class Store extends AbstractStore {

    public Store(int maxCustomers) {
        super(maxCustomers);
    }

    @Override
    protected synchronized void signalCustomerExitStore() {
        notifyAll();
    }

    @Override
    protected synchronized void signalCustomerEnteredStore() {
        notifyAll();
    }

    @Override
    protected synchronized void waitCapacityLimit() throws InterruptedException {
        while (isFull()) {
            wait();
        }
    }

    @Override
    protected synchronized void waitCustomers() throws InterruptedException {
        while (isEmpty()) {
            wait();
        }
    }
}
