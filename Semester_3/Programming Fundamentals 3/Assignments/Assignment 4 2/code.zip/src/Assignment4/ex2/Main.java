package Assignment4.ex2;

public class Main {
	private static final int STORE_CAPACITY = 10;
	private static final int NUM_CUSTOMERS = 100;
	private static final int NUM_SALESPERSONS = 3;

	public static void main(String[] args) throws InterruptedException {
		final AbstractStore store = new Store(STORE_CAPACITY);
		final Customer[] customers = new Customer[NUM_CUSTOMERS];
		final SalesPerson[] salesPersons = new SalesPerson[NUM_SALESPERSONS];
		
		for(int i=0; i<NUM_CUSTOMERS; i++) {
			customers[i] = new Customer(store);
			customers[i].start();
		}

		for(int i=0; i<NUM_SALESPERSONS; i++) {
			salesPersons[i] = new SalesPerson(store);
			salesPersons[i].start();
		}
		
		for(Thread customer : customers) {
			customer.join();
		}
		
		for(Thread salesPerson : salesPersons) {
			salesPerson.interrupt();
		}
	}
}
