package Assignment4.ex2;

import java.util.Deque;
import java.util.LinkedList;
import java.util.Random;

class Customer extends Thread {
	private static final int MAX_ITEMS = 3;
	
	private final AbstractStore store;
	private final Deque<Item> shoppingCart = new LinkedList<>();
	private final int numNeededItems = new Random().nextInt(MAX_ITEMS) + 1;
	private int ticketNumber;
	
	public Customer(AbstractStore store) {
		this.store = store;
	}
	
	public int getTicketNumber() {
		return ticketNumber;
	}

	public void setTicketNumber(int ticketNumber) {
		this.ticketNumber = ticketNumber;
	}
	
	@Override
	public void run() {
		try {
			store.enterStore(this);
			System.out.println(this + " enters the store.");			
			synchronized (shoppingCart) {
				while(shoppingCart.size() < numNeededItems) {
					// customer waits to get all needed items
					shoppingCart.wait();
				}
			}
			System.out.println(this + " has left the store.");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void serveItem(Item o) {
		synchronized (shoppingCart) {
			shoppingCart.add(o);						
			if(shoppingCart.size() == numNeededItems) {
				// notify customer when all needed items have been served
				shoppingCart.notify();
			}
		}
	}	

	public boolean needsItems() {
		synchronized (shoppingCart) {
			return shoppingCart.size() < numNeededItems;
		}
	}
	
	@Override
	public String toString() {
		return "customer n. " + ticketNumber;
	}	
}