package Assignment4.ex2;

public class SalesPerson extends Thread {
	private final AbstractStore store;
	
	public SalesPerson(AbstractStore store) {
		this.store = store;
	}
	
	@Override
	public void run() {
		try {
			while(true) {
				store.serveCustomer();				
			}
		} catch (InterruptedException e) { }
	}
}