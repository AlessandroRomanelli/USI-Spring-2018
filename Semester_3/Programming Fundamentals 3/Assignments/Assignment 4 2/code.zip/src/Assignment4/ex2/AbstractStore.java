package Assignment4.ex2;

import java.util.Deque;
import java.util.LinkedList;
import java.util.Random;

abstract class AbstractStore {	
	public static int MAX_SHOPPING_TIME = 1000;
	
	private int TICKETS = 0;	
	private final Deque<Customer> customers;
	private final Random random;
	private final int maxCustomers;

	public AbstractStore(int maxCustomers) {
		this.maxCustomers = maxCustomers;
		customers = new LinkedList<Customer>();
		random = new Random();
	}
		
	public synchronized void enterStore(Customer customer)
			throws InterruptedException {
		waitCapacityLimit();
		customers.add(customer);
		customer.setTicketNumber(++TICKETS);
		signalCustomerEnteredStore();
	}
	
	public synchronized void serveCustomer() throws InterruptedException {
		waitCustomers();
		Customer customer = customers.pop();
		System.out.println("Sales person " + Thread.currentThread().getName() +
				" is serving " + customer);
		Thread.sleep(random.nextInt(MAX_SHOPPING_TIME));
		while(customer.needsItems()) {
			customer.serveItem(new Item());
		}
		signalCustomerExitStore();
	}
	
	public synchronized boolean isFull() {
		return customers.size() == maxCustomers;
	}
	
	public synchronized boolean isEmpty() {
		return customers.isEmpty();
	}

	protected abstract void waitCapacityLimit() throws InterruptedException;
	protected abstract void waitCustomers() throws InterruptedException;
	protected abstract void signalCustomerEnteredStore();
	protected abstract void signalCustomerExitStore();
}
