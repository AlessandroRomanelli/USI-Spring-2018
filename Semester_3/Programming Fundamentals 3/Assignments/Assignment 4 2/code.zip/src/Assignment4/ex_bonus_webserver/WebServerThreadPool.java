package Assignment4.ex_bonus_webserver;

import java.util.concurrent.*;

public class WebServerThreadPool  extends WebServer {
    private ExecutorService executor;
    public WebServerThreadPool(int cpus) {
        this.executor =  Executors.newFixedThreadPool(cpus);
    }

    @Override
    public void concurrentRequestHandler(Runnable runnable) {
        executor.execute(runnable);
    }
}
