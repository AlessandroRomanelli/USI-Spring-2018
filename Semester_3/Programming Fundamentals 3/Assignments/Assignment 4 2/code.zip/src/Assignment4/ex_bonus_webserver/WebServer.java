package Assignment4.ex_bonus_webserver;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;

public class WebServer implements Runnable {
	private final static int TIMEOUT = 3000;

	@Override
	public void run() {
		try(final ServerSocket socket = new ServerSocket(8080)) {
			socket.setSoTimeout(TIMEOUT);
			while(true) {
				final Socket connection = socket.accept();
				concurrentRequestHandler(new Runnable() {
					@Override
					public void run() {
						handleRequest(connection);
					}
				});
			}	
		} catch (SocketTimeoutException e) {
			System.out.println("Exit");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void handleRequest(final Socket connection) {
		System.out.println("Handling HTTP request: " + connection);
	}
	
	public void concurrentRequestHandler(Runnable runnable) {
		new Thread(runnable).start();
	}
}
