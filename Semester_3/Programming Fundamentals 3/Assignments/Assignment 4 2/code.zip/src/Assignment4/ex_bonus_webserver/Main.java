package Assignment4.ex_bonus_webserver;

public class Main {
	
	public static void main(String[] args) {
		final int cpus = Runtime.getRuntime().availableProcessors();
		new Thread(new WebServerThreadPool(cpus)).start();
	}
}
