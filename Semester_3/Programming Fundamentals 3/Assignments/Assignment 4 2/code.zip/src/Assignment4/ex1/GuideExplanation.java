package Assignment4.ex1;

public class GuideExplanation implements Runnable {
	@Override
	public void run() {
		System.out.println("The guide is explaining local attractions.");
	}
}