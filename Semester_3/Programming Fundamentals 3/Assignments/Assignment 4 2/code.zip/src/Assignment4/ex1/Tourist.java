package Assignment4.ex1;

import java.util.Random;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class Tourist implements Runnable {
	private static final int MAX_SLEEP = 1000;
	
	private final String[] places;
	private final Random random;
	private final CyclicBarrier barrier;
	
	public Tourist(String[] places, CyclicBarrier barrier) {
		this.places = places; 
		this.barrier = barrier;
		random = new Random();
	}
	
	@Override
	public void run() {
		try {
			for(String place : places) {
				System.out.println(Thread.currentThread().getName() + 
						" is travelling towards " + place + ".");
				Thread.sleep(random.nextInt(MAX_SLEEP));
				try {
					waitGroup();
				} catch(BrokenBarrierException e) {
					e.printStackTrace();
				}
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	private void waitGroup() throws InterruptedException, BrokenBarrierException {
		// TODO implement waitGroup method
		try {
			barrier.await(MAX_SLEEP, TimeUnit.SECONDS);
		} catch (TimeoutException e) {}
	}
}