package Assignment4.ex1;

import java.util.concurrent.CyclicBarrier;

public class Main {
	static final int N_TOURISTS = 10;
	static final String[] PLACES = {
			"Place 1", "Place 2", "Place 3", "Place 4", "Place 5"};
		
	public static void main(String[] args) {
		// TODO: instantiate the cyclic barrier
		Runnable guide = new GuideExplanation();
		CyclicBarrier barrier = new CyclicBarrier(N_TOURISTS, guide);
 		for(int i=0; i<N_TOURISTS; i++) {
			// TODO: instantiate and start i-th tourist thread
			Tourist tourist = new Tourist(PLACES, barrier);
			new Thread(tourist).start();
		}
	}
}