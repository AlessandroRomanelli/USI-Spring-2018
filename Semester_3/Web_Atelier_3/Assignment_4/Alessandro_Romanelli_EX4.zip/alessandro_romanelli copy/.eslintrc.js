module.exports = {
    "extends": "airbnb-base"
};